package library
func Text() string { return "versioned-dependency" }
