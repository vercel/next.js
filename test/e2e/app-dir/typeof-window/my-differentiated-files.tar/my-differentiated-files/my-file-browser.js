export default 'BROWSER'
