export default 'SERVER'
