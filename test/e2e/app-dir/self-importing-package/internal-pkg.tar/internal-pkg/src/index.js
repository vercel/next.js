import { env } from 'internal-pkg/env'

export default `${env} abc`
