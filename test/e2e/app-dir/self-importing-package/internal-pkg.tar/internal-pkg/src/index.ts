import { env } from "./env";

console.log({ env });
