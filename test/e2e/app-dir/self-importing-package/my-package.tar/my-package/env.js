export const message = 'THIS IS THE OTHER FILE'
