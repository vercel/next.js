import { message } from 'my-package/env'

export const myMessage = message
